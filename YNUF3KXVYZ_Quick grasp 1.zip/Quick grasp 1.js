// Function to set the active menu item
function setActive(event) {
    // Remove active class from all menu items
    document.querySelectorAll('.menu-item').forEach(item => {
        item.classList.remove('active');
    });

    // Add active class to the clicked item
    event.target.classList.add('active');

    // Redirect to the target page
    window.location.href = event.target.getAttribute('href');
}

// Keep the selected tab active after refresh
window.onload = function() {
    const currentPage = window.location.pathname.split('/').pop();
    document.querySelectorAll('.menu-item').forEach(item => {
        if (item.getAttribute('href') === currentPage) {
            item.classList.add('active');
        }
    });
};